"""Reproducible validation + cleaning for healthcare_patients_sample.csv
Run: python clean_patients.py   (needs pandas)
Rules never impute or invent clinical values: bad/missing values are flagged, not filled."""
import pandas as pd, re

RAW = "raw_healthcare_patients_sample.csv"
df = pd.read_csv(RAW, dtype=str)
log = []  # exception log rows

def flag(pid, field, value, rule, severity, action):
    log.append(dict(PatientID=pid, Field=field, Value=value, Rule=rule, Severity=severity, Action=action))

# ---- Rules ----
EXPECTED = ["PatientID","Age","Gender","Diagnosis","PrimaryMedication","DosageMg",
            "TreatmentDurationDays","Readmitted","BloodPressure","CholesterolLevel"]
missing_cols = set(EXPECTED) - set(df.columns)
assert not missing_cols, f"Missing columns: {missing_cols}"

# normalise whitespace / case on categorical text only (no clinical value changes)
for c in ["PatientID","Gender","Diagnosis","PrimaryMedication","Readmitted"]:
    before = df[c].copy()
    df[c] = df[c].str.strip()
    for i in df.index[before != df[c]]:
        flag(df.at[i,"PatientID"], c, before[i], "Leading/trailing whitespace", "Low", "Trimmed")
df["Gender"] = df["Gender"].str.title()
df["Readmitted"] = df["Readmitted"].str.title()

# 1. missing values
for c in EXPECTED:
    for i in df.index[df[c].isna() | (df[c].str.strip()=="")]:
        flag(df.at[i,"PatientID"], c, "", "Missing value", "Medium", "Left blank (not imputed)")

# 2. duplicate IDs / rows
for i in df.index[df.duplicated("PatientID", keep="first")]:
    flag(df.at[i,"PatientID"], "PatientID", df.at[i,"PatientID"], "Duplicate PatientID", "High", "Removed (exact duplicate)" if df.loc[i].equals(df[df.PatientID==df.at[i,'PatientID']].iloc[0]) else "Kept for manual review")
df = df.drop_duplicates()  # exact duplicate rows only

# 3. ID format
for i in df.index[~df.PatientID.fillna("").str.fullmatch(r"PAT-\d{3,}")]:
    flag(df.at[i,"PatientID"], "PatientID", df.at[i,"PatientID"], "ID format PAT-###", "Medium", "Flagged")

# 4. types
num = {"Age":int, "DosageMg":float, "TreatmentDurationDays":int, "CholesterolLevel":int}
for c in num:
    conv = pd.to_numeric(df[c], errors="coerce")
    for i in df.index[conv.isna() & df[c].notna()]:
        flag(df.at[i,"PatientID"], c, df.at[i,c], "Non-numeric value", "High", "Set to null")
    df[c] = conv

# 5. ranges (plausibility limits, documented in data dictionary)
ranges = {"Age":(0,120), "DosageMg":(0.001,2000), "TreatmentDurationDays":(1,730), "CholesterolLevel":(80,400)}
for c,(lo,hi) in ranges.items():
    for i in df.index[df[c].notna() & ~df[c].between(lo,hi)]:
        flag(df.at[i,"PatientID"], c, df.at[i,c], f"Outside {lo}-{hi}", "High", "Set to null, flagged for clinical review")
        df.at[i,c] = pd.NA

# 6. categorical domains
for c, ok in {"Gender":{"Male","Female","Other","Unknown"}, "Readmitted":{"Yes","No"}}.items():
    for i in df.index[df[c].notna() & ~df[c].isin(ok)]:
        flag(df.at[i,"PatientID"], c, df.at[i,c], f"Not in {sorted(ok)}", "Medium", "Set to null")
        df.at[i,c] = pd.NA

# 7. blood pressure parse + sanity
bp = df.BloodPressure.str.extract(r"^\s*(\d{2,3})\s*/\s*(\d{2,3})\s*$")
for i in df.index[bp[0].isna() & df.BloodPressure.notna()]:
    flag(df.at[i,"PatientID"],"BloodPressure",df.at[i,"BloodPressure"],"Not systolic/diastolic format","High","Set to null")
df["SystolicBP"] = pd.to_numeric(bp[0]); df["DiastolicBP"] = pd.to_numeric(bp[1])
bad = (df.SystolicBP<70)|(df.SystolicBP>250)|(df.DiastolicBP<40)|(df.DiastolicBP>150)|(df.SystolicBP<=df.DiastolicBP)
for i in df.index[bad]:
    flag(df.at[i,"PatientID"],"BloodPressure",df.at[i,"BloodPressure"],"Implausible BP","High","Set to null")
    df.loc[i,["SystolicBP","DiastolicBP"]] = pd.NA

# 8. clinical-consistency flags (flag only, never change)
for i in df.index:
    if df.at[i,"Diagnosis"]=="Hypertension" and pd.notna(df.at[i,"SystolicBP"]) and df.at[i,"SystolicBP"]>=180:
        flag(df.at[i,"PatientID"],"BloodPressure",df.at[i,"BloodPressure"],"Hypertensive-crisis range","High","Flagged for clinical review")
    if pd.notna(df.at[i,"Age"]) and df.at[i,"Age"]>=65 and df.at[i,"Readmitted"]=="Yes":
        pass  # informational only; not an error

# 9. medication dose-unit watch (Levothyroxine is usually mcg; 0.05 mg = 50 mcg)
for i in df.index[df.PrimaryMedication.eq("Levothyroxine") & (df.DosageMg<1)]:
    flag(df.at[i,"PatientID"],"DosageMg",df.at[i,"DosageMg"],"Low mg value; drug usually labelled in mcg (0.05 mg = 50 mcg)","Info","Kept as-is; documented unit")

df = df.drop(columns=["BloodPressure"]).rename(columns={})
df.to_csv("clean_healthcare_patients.csv", index=False)
cols = ["PatientID","Field","Value","Rule","Severity","Action"]
pd.DataFrame(log, columns=cols).to_csv("exception_log.csv", index=False)

# summary
print("rows in:", len(pd.read_csv(RAW)), "rows out:", len(df), "exceptions:", len(log))
print(pd.DataFrame(log, columns=cols).to_string(index=False))
